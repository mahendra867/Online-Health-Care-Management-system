from tkinter import*
from tkinter import ttk
from tkinter import messagebox

class medication:
    def __init__(self,root):
        self.root=root
        self.root.title("Medication")
        self.root.geometry("1600x900+0+0")

        lbltitle=Label(self.root,bd=20,relief=RIDGE,text="MEDICATION",fg="white",bg="black",font=("times new roman",32,"bold"))
        lbltitle.pack(side=TOP,fill=X)

        prsctframe=Frame(self.root,bd=15,relief=RIDGE)
        prsctframe.place(x=70,y=150,width=1400,height=50)
        lblprsct=Label(prsctframe,text="PRESCRIPTION",fg="white",bg="green",font=("times new roman",16,"bold"),padx=6,pady=6)
        lblprsct.pack(fill=X)

        medframe=Frame(self.root,bd=15,relief=RIDGE)
        medframe.place(x=70,y=200,width=700,height=400)

        lblpid=Label(medframe,text="Patient ID",font=("times new roman",12,"bold"),padx=2,pady=6)
        lblpid.grid(row=0,column=0)
        txtpid=ttk.Entry(medframe,font=("times new roman",12,"bold"),width=35)
        txtpid.grid(row=0,column=1)

        lblage=Label(medframe,text="Age of Patient",font=("times new roman",12,"bold"),padx=2,pady=6)
        lblage.grid(row=1,column=0)
        txtage=ttk.Entry(medframe,font=("times new roman",12,"bold"),width=35)
        txtage.grid(row=1,column=1)

        lblNameTablet=Label(medframe,text="Name of the tablet 1",font=("times new roman",12,"bold"),padx=2,pady=6)
        lblNameTablet.grid(row=2,column=0)
        comNameTablet=ttk.Combobox(medframe,font=("times new roman",12,"bold"),width=33)
        comNameTablet["values"]=("Halothane with vaporizer","Isoflurane","Ketamine Hydrochloride","Propofol","Diazepam","Acetyl Salicylic Acid Tab","Diclofenac Tab","Ibuprofen","Paracetamol Tab","Paracetamol Syrup","Paracetamol Injection","Azathioprine",
                                "Hydroxychloroquine phosphate","Adrenaline Bitartrate","Cetrizine","Activated Charcoal Antidote","Dimercaprol","Amoxicillin","Ampicillin","Azithromycin","Fluconazole","Metronidazole","Clindamycin","Dolo","--blood--","Dextran-40","Dextran-70",
                                "Fresh frozen plasma","Hydroxyethyl Starch (Hetastarch)","Polygeline","Albumin","Platelet Rich Plasma","--heart--","Acetyl salicylic acid","Diltiazem","Metoprolol","Digoxin","Dobutamine","--Contraceptives & Hormones--","Testosterone","Condoms",
                                "IUD containing Copper","Hormone Releasing IUD","Hormone Releasing IUD","Insulin Injection","Telmind25","--Vitamins & Minerals--","Ascorbic Acid",
                                "Calcium carbonate","Multivitamins","Nicotinamide","Vitamin A","Thiamine","Vitamin D (Ergocalciferol)","Calcium gluconate","--Cancer--","Asparaginase","Bleomycin","Carboplatin","Cytarabine","Docetaxel","Etoposide","Procarbazine","Vincristine",
                                "Mesna","Fludarabine","Rituximab","Arsenic trioxide","Dasatinib","Nilotinib")
        comNameTablet.grid(row=2,column=1)

        lblNameTablet1=Label(medframe,text="Name of the tablet 2",font=("times new roman",12,"bold"),padx=2,pady=6)
        lblNameTablet1.grid(row=3,column=0)
        comNameTablet1=ttk.Combobox(medframe,font=("times new roman",12,"bold"),width=33)
        comNameTablet1["values"]=("Halothane with vaporizer","Isoflurane","Ketamine Hydrochloride","Propofol","Diazepam","Acetyl Salicylic Acid Tab","Diclofenac Tab","Ibuprofen","Paracetamol Tab","Paracetamol Syrup","Paracetamol Injection","Azathioprine",
                                "Hydroxychloroquine phosphate","Adrenaline Bitartrate","Cetrizine","Activated Charcoal Antidote","Dimercaprol","Amoxicillin","Ampicillin","Azithromycin","Fluconazole","Metronidazole","Clindamycin","Dolo","--blood--","Dextran-40","Dextran-70",
                                "Fresh frozen plasma","Hydroxyethyl Starch (Hetastarch)","Polygeline","Albumin","Platelet Rich Plasma","--heart--","Acetyl salicylic acid","Diltiazem","Metoprolol","Digoxin","Dobutamine","--Contraceptives & Hormones--","Testosterone","Condoms",
                                "IUD containing Copper","Hormone Releasing IUD","Hormone Releasing IUD","Insulin Injection","Telmind25","--Vitamins & Minerals--","Ascorbic Acid",
                                "Calcium carbonate","Multivitamins","Nicotinamide","Vitamin A","Thiamine","Vitamin D (Ergocalciferol)","Calcium gluconate","--Cancer--","Asparaginase","Bleomycin","Carboplatin","Cytarabine","Docetaxel","Etoposide","Procarbazine","Vincristine",
                                "Mesna","Fludarabine","Rituximab","Arsenic trioxide","Dasatinib","Nilotinib")
        comNameTablet1.grid(row=3,column=1)

        lblNameTablet2=Label(medframe,text="Name of the tablet 3",font=("times new roman",12,"bold"),padx=2,pady=6)
        lblNameTablet2.grid(row=4,column=0)
        comNameTablet2=ttk.Combobox(medframe,font=("times new roman",12,"bold"),width=33)
        comNameTablet2["values"]=("Halothane with vaporizer","Isoflurane","Ketamine Hydrochloride","Propofol","Diazepam","Acetyl Salicylic Acid Tab","Diclofenac Tab","Ibuprofen","Paracetamol Tab","Paracetamol Syrup","Paracetamol Injection","Azathioprine",
                                "Hydroxychloroquine phosphate","Adrenaline Bitartrate","Cetrizine","Activated Charcoal Antidote","Dimercaprol","Amoxicillin","Ampicillin","Azithromycin","Fluconazole","Metronidazole","Clindamycin","Dolo","--blood--","Dextran-40","Dextran-70",
                                "Fresh frozen plasma","Hydroxyethyl Starch (Hetastarch)","Polygeline","Albumin","Platelet Rich Plasma","--heart--","Acetyl salicylic acid","Diltiazem","Metoprolol","Digoxin","Dobutamine","--Contraceptives & Hormones--","Testosterone","Condoms",
                                "IUD containing Copper","Hormone Releasing IUD","Hormone Releasing IUD","Insulin Injection","Telmind25","--Vitamins & Minerals--","Ascorbic Acid",
                                "Calcium carbonate","Multivitamins","Nicotinamide","Vitamin A","Thiamine","Vitamin D (Ergocalciferol)","Calcium gluconate","--Cancer--","Asparaginase","Bleomycin","Carboplatin","Cytarabine","Docetaxel","Etoposide","Procarbazine","Vincristine",
                                "Mesna","Fludarabine","Rituximab","Arsenic trioxide","Dasatinib","Nilotinib")
        comNameTablet2.grid(row=4,column=1)

        lblqty=Label(medframe,text="Quantity Tab1",font=("times new roman",12,"bold"),padx=2,pady=6)
        lblqty.grid(row=5,column=0)
        comqty=ttk.Combobox(medframe,font=("times new roman",12,"bold"),width=33)
        comqty["values"]=("--Select--","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15")
        comqty.grid(row=5,column=1)

        lblqty1=Label(medframe,text="Quantity Tab2",font=("times new roman",12,"bold"),padx=2,pady=6)
        lblqty1.grid(row=6,column=0)
        comqty1=ttk.Combobox(medframe,font=("times new roman",12,"bold"),width=33)
        comqty1["values"]=("--Select--","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15")
        comqty1.grid(row=6,column=1)

        lblqty2=Label(medframe,text="Quantity Tab3",font=("times new roman",12,"bold"),padx=2,pady=6)
        lblqty2.grid(row=7,column=0)
        comqty2=ttk.Combobox(medframe,font=("times new roman",12,"bold"),width=33)
        comqty2["values"]=("--Select--","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15")
        comqty2.grid(row=7,column=1)

        lblamt=Label(medframe,text="Amount in Rs.",font=("times new roman",12,"bold"),padx=2,pady=6)
        lblamt.grid(row=8,column=0)
        txtamt=ttk.Entry(medframe,font=("times new roman",12,"bold"),width=35)
        txtamt.grid(row=8,column=1)

        lbltype=Label(medframe,text="Payment Type",font=("times new roman",12,"bold"),padx=2,pady=6)
        lbltype.grid(row=9,column=0)
        comtype=ttk.Combobox(medframe,font=("times new roman",12,"bold"),width=33)
        comtype["values"]=("Cash","UPI","Digital payment")
        comtype.grid(row=9,column=1)

        btnpst=Button(medframe,command=self.showprsct,text="Prescribe",font=("times new roman",12,"bold"),width=20,height=2,bd=2,relief=RIDGE,fg="black",bg="green",activebackground="green",activeforeground="black")
        btnpst.place(x=460,y=150)

        btndashboard=Button(medframe,text="Back to Mainpage",font=("times new roman",12,"bold"),width=20,height=2,bd=2,relief=RIDGE,fg="black",bg="red",activebackground="red",activeforeground="black")
        btndashboard.place(x=460,y=210)

        #prescription output Frame
        pstoframe=Frame(self.root,bd=15,relief=RIDGE)
        pstoframe.place(x=770,y=200,width=700,height=400)

        self.txtpst=Text(pstoframe,font=("times new roman",12,"bold"),width=83,height=19,padx=2,pady=6)
        self.txtpst.grid(row=0,column=0)

    def showprsct(self):
        self.txtpst.insert(END,"Patient ID:\t\t\t"+self.pid.get() + "\n")
        #self.txtpst=self.pid.get()
        self.txtpst.insert(END,"Age of Patient:\t\t\t"+self.pid.get() + "\n")
        self.txtpst.insert(END,"Name of the tablet 1:\t\t\t"+self.NameTable.get() + "\n")
        self.txtpst.insert(END,"Name of the tablet 2:\t\t\t"+self.NameTable1.get() + "\n")
        self.txtpst.insert(END,"Name of the tablet 3:\t\t\t"+self.NameTable2.get() + "\n")
        self.txtpst.insert(END,"Quantity Tab1:\t\t\t"+self.qty.get() + "\n")
        self.txtpst.insert(END,"Quantity Tab2:\t\t\t"+self.qty1.get() + "\n")
        self.txtpst.insert(END,"Quantity Tab3:\t\t\t"+self.qty2.get() + "\n")
        self.txtpst.insert(END,"Amount in Rs.:\t\t\t"+self.amt.get() + "\n")
        self.txtpst.insert(END,"Payment Type:\t\t\t"+self.type.get() + "\n")

        if self.pid.get() == '' or self.NameTable.get() == '' or self.NameTable1.get() == '' or self.NameTable2.get() == '' or self.qty.get() == '' or self.qty1.get() == '' or self.qty2.get() == '' or self.amt.get() == '' or self.type.get() == '':
            messagebox.showerror("Warning", "Please Fill Up All Boxes")
        else:
            # now we add to the database
            sql = "INSERT INTO 'medication' (Patient ID, Age of Patient, Name of the tablet 1, Name of the tablet 2, Name of the tablet 3, Quantity Tab1, Quantity Tab2, Quantity Tab3, Amount in Rs., Payment Type) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            c.execute(sql, (self.pid, self.age, self.NameTable, self.NameTable1, self.NameTable2, self.qty, self.qty1, self.qty2, self.amt, self.type))
            conn.commit()
            messagebox.showinfo("Success", "Prescribed!")


if __name__ == '__main__':
    root=Tk()
    app=medication(root)
    root.mainloop()
