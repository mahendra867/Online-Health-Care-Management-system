from tkinter import*
from tkinter import ttk
from tkinter import messagebox
import random
import time
import datetime

class mainpage:
    def __init__(self,root):
        self.root=root
        self.root.title("Main Page")
        self.root.geometry("1550x800+0+0")

        lbltitle=Label(self.root,bd=20,relief=RIDGE,text="Online Health Management System",fg="white",bg="black",font=("times new roman",32,"bold"))
        lbltitle.pack(side=TOP,fill=X)
        
        buttonframe=Frame(self.root,bd=10,relief=RIDGE)
        buttonframe.place(x=0,y=172,width=1550,height=70)

        lblquick=Label(buttonframe,text="QUICK LINKS:",font=("times new roman",16,"bold"),padx=6,pady=6)
        lblquick.grid(row=0,column=0)

        btnapnt=Button(buttonframe,text="Book An Apointment",bg="red",fg="black",font=("times new roman",8,"bold"),padx=2,pady=2)
        btnapnt.place(x=160,y=0,width=200,height=50)

        test=Button(buttonframe,text="Tests",bg="red",fg="black",font=("times new roman",8,"bold"),padx=2,pady=2)
        test.place(x=400,y=0,width=200,height=50)

        mdct=Button(buttonframe,text="Medication",bg="red",fg="black",font=("times new roman",8,"bold"),padx=2,pady=2)
        mdct.place(x=640,y=0,width=200,height=50)

        vac=Button(buttonframe,text="Vaccines",bg="red",fg="black",font=("times new roman",8,"bold"),padx=2,pady=2)
        vac.place(x=880,y=0,width=200,height=50)

        rpt=Button(buttonframe,text="Reports",bg="red",fg="black",font=("times new roman",8,"bold"),padx=2,pady=2)
        rpt.place(x=1120,y=0,width=200,height=50)

        bdd=Button(buttonframe,text="Blood Donate",bg="red",fg="black",font=("times new roman",8,"bold"),padx=2,pady=2)
        bdd.place(x=1360,y=0,width=150,height=50)

        descframe=Frame(self.root,bd=10,relief=RIDGE)
        descframe.place(x=0,y=250,width=1550,height=150)

        lbldesc=Label(descframe,text="Welcome to Online Health Management System! \n Get well at one touch on your device resting at your home.This health management system makes it easy to find the doctors, which helps the patients to recover faster\n from the disease. Get your health reports and required tests. Finding the best respective doctor for a particular disease manually is a tough task.\n This health management system helps to find respective specialist doctors for a particular disease in the nearby location and also provides\n information and tips on how the disease can be cured. Get an appointment and either visit the clinic or request for home visit.",fg="white",bg="black",font=("times new roman",16,"bold"),padx=6,pady=6)
        lbldesc.pack(fill=X)

        boxframe=Frame(self.root,bd=10,relief=RIDGE)
        boxframe.place(x=0,y=400,width=1550,height=50)
        lblbox=Label(boxframe,text="Doctors Recommended",fg="white",bg="green",font=("times new roman",16,"bold"),padx=6,pady=6)
        lblbox.pack(fill=X)

        doctzeroframe=Frame(self.root,bd=10,relief=RIDGE)
        doctzeroframe.place(x=60,y=450,width=200,height=375)
        lbldoctzero=Label(doctzeroframe,text="HEART\nSPECIALIST\n\nDr.Ajit Singh Doval\n(MBBS)\n\nExperience:23 Y",fg="white",bg="grey",font=("times new roman",14,"bold"),padx=0,pady=0)
        lbldoctzero.pack(fill=X)
        btndoctzero=Button(doctzeroframe,text="Contact",bg="green",fg="black",font=("times new roman",8,"bold"),padx=2,pady=2)
        btndoctzero.place(x=12,y=240,width=150,height=50)

        doctoneframe=Frame(self.root,bd=10,relief=RIDGE)
        doctoneframe.place(x=260,y=450,width=200,height=375)
        lbldoctone=Label(doctoneframe,text="LAB\nANALYST\n\nDr.Dishika Sharma\n(MBBS)\n\nExperience:25 Y",fg="white",bg="grey",font=("times new roman",14,"bold"),padx=0,pady=0)
        lbldoctone.pack(fill=X)
        btndoctone=Button(doctoneframe,text="Contact",bg="green",fg="black",font=("times new roman",8,"bold"),padx=2,pady=2)
        btndoctone.place(x=12,y=240,width=150,height=50)

        docttwoframe=Frame(self.root,bd=10,relief=RIDGE)
        docttwoframe.place(x=460,y=450,width=200,height=375)
        lbldocttwo=Label(docttwoframe,text="BONE\nSPECIALIST\n\nDr.Mahendra\n(MBBS)\n\nExperience:23 Y",fg="white",bg="grey",font=("times new roman",14,"bold"),padx=0,pady=0)
        lbldocttwo.pack(fill=X)
        btndocttwo=Button(docttwoframe,text="Contact",bg="green",fg="black",font=("times new roman",8,"bold"),padx=2,pady=2)
        btndocttwo.place(x=12,y=240,width=150,height=50)

        doctthreeframe=Frame(self.root,bd=10,relief=RIDGE)
        doctthreeframe.place(x=660,y=450,width=200,height=375)
        lbldoctthree=Label(doctthreeframe,text="VETERNARY\nSPECIALIST\n\nDr.Avira Dessai\n(MBBS)\n\nExperience:18 Y",fg="white",bg="grey",font=("times new roman",14,"bold"),padx=0,pady=0)
        lbldoctthree.pack(fill=X)
        btndoctthree=Button(doctthreeframe,text="Contact",bg="green",fg="black",font=("times new roman",8,"bold"),padx=2,pady=2)
        btndoctthree.place(x=12,y=240,width=150,height=50)

        doctfourframe=Frame(self.root,bd=10,relief=RIDGE)
        doctfourframe.place(x=860,y=450,width=200,height=375)
        lbldoctfour=Label(doctfourframe,text="DENTIST\n\n\nDr.Rutuja Dessai\n(MBBS)\n\nExperience:21 Y",fg="white",bg="grey",font=("times new roman",14,"bold"),padx=0,pady=0)
        lbldoctfour.pack(fill=X)
        btndoctfour=Button(doctfourframe,text="Contact",bg="green",fg="black",font=("times new roman",8,"bold"),padx=2,pady=2)
        btndoctfour.place(x=12,y=240,width=150,height=50)

        doctfiveframe=Frame(self.root,bd=10,relief=RIDGE)
        doctfiveframe.place(x=1060,y=450,width=200,height=375)
        lbldoctfive=Label(doctfiveframe,text="EYE\nSPECIALIST\n\nDr.Sukhvir Kaur\n(MBBS)\n\nExperience:28 Y",fg="white",bg="grey",font=("times new roman",14,"bold"),padx=0,pady=0)
        lbldoctfive.pack(fill=X)
        btndoctfive=Button(doctfiveframe,text="Contact",bg="green",fg="black",font=("times new roman",8,"bold"),padx=2,pady=2)
        btndoctfive.place(x=12,y=240,width=150,height=50)

        doctsixframe=Frame(self.root,bd=10,relief=RIDGE)
        doctsixframe.place(x=1260,y=450,width=200,height=375)
        lbldoctsix=Label(doctsixframe,text="CANCER\nSPECIALIST\n\nDr.Bratt\n(MBBS)\n\nExperience:30 Y",fg="white",bg="grey",font=("times new roman",14,"bold"),padx=0,pady=0)
        lbldoctsix.pack(fill=X)
        btndoctsix=Button(doctsixframe,text="Contact",bg="green",fg="black",font=("times new roman",8,"bold"),padx=2,pady=2)
        btndoctsix.place(x=12,y=240,width=150,height=50)



if __name__ == '__main__':
    root=Tk()
    app=mainpage(root)
    root.mainloop()
