from tkinter import*
from tkinter import ttk
from tkinter import messagebox

class test:
    #calling constructor
    def __init__(self,root):
        self.root=root
        self.root.title("Create New Account")
        self.root.geometry("1600x900+0+0")

        self.var_orderid=IntVar()
        self.var_fname=StringVar()
        self.var_contact=StringVar()
        self.var_drname=StringVar()
        self.var_pay=IntVar()
        self.var_testname=StringVar()
        self.var_checkbtn=IntVar()

        frame=Frame(self.root,bg="black")
        frame.place(x=0,y=0,width=1550,height=840)

        testlbl=Label(frame,text="TESTS",font=("times new roman",28,"bold"),fg="yellow",bg="black")
        testlbl.place(x=100,y=20)

        orderid=Label(frame,text="Test ID:",font=("times new roman",16,"bold"),fg="white",bg="black")
        orderid.place(x=700,y=20)
        self.txt_orderid=ttk.Entry(frame,textvariable=self.var_orderid,font=("times new roman",15))
        self.txt_orderid.place(x=700,y=50,width=250)

        fname=Label(frame,text="Full Name",font=("times new roman",16,"bold"),fg="white",bg="black")
        fname.place(x=100,y=110)
        self.txt_fname=ttk.Entry(frame,textvariable=self.var_fname,font=("times new roman",15))
        self.txt_fname.place(x=100,y=140,width=250)

        contact=Label(frame,text="Contact Number",font=("times new roman",16,"bold"),fg="white",bg="black")
        contact.place(x=500,y=110)
        self.txt_contact=ttk.Entry(frame,textvariable=self.var_contact,font=("times new roman",15))
        self.txt_contact.place(x=500,y=140,width=250)

        drname=Label(frame,text="Doctor Name",font=("times new roman",16,"bold"),fg="white",bg="black")
        drname.place(x=900,y=110)
        self.txt_drname=ttk.Entry(frame,textvariable=self.var_drname,font=("times new roman",15))
        self.txt_drname.place(x=900,y=140,width=250)

        pay=Label(frame,text="Amount Payable",font=("times new roman",16,"bold"),fg="white",bg="black")
        pay.place(x=100,y=240)
        self.txt_pay=ttk.Entry(frame,textvariable=self.var_pay,font=("times new roman",15))
        self.txt_pay.place(x=100,y=270,width=250)

        testname=Label(frame,text="Select particular\n required Test", font=("times new roman",16,"bold"),fg="white",bg="black")
        testname.place(x=1300,y=110)
        self.combo_testname=ttk.Combobox(frame,textvariable=self.var_testname,font=("times new roman",15,"bold"),state="readonly")
        self.combo_testname["values"]=("Select","Blood","Urine","Endoscopy","Biopsy","Genetic Testing")
        self.combo_testname.place(x=1300,y=140,width=250)
        self.combo_testname.current(0)

        checkbtn=Checkbutton(frame,variable=self.var_checkbtn,text="I agree with all terms & conditions",font=("times new roman",8,"bold"),onvalue=1,offvalue=0)
        checkbtn.place(x=100,y=320)

        b1=Button(frame,command=self.test_data,text="Done",font=("times new roman",12,"bold"),bd=2,relief=RIDGE,fg="black",bg="red",activebackground="red",activeforeground="black")
        b1.place(x=100,y=420,width=100)

        listlbl=Label(frame,text="RATE OF ALL TESTS\n 1.Blood: Rs.300\n 2.Urine: Rs100\n 3.Endoscopy: Rs1500\n 4.Biopsy: Rs5000\n 5.Genetic Testing: Rs6500",font=("times new roman",28,"bold"),fg="white",bg="grey")
        listlbl.place(x=900,y=250)

    def test_data(self):
        if self.var_orderid.get()=="" or self.var_fname.get()=="" or self.var_contact.get()=="" or self.var_testname.get()=="Select":
            messagebox.showerror("Error","All fields are mandatory")
        elif self.var_checkbtn.get()==0:
            messagebox.showerror("Error","Please check the box after you read terms and conditions")
        else:
            messagebox.showinfo("Successful","Sample will be collected soon!")


if __name__ == '__main__':
    root=Tk()
    app=test(root)
    root.mainloop()
