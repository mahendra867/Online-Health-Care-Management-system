from tkinter import*
from tkinter import ttk
from tkinter import messagebox
import time
import datetime

class appointment:
    def __init__(self,root):
        self.root=root
        self.root.title("Book an appointment")
        self.root.geometry("1600x900+0+0")



        lbltitle=Label(self.root,bd=20,relief=RIDGE,text="Online Health Management System",fg="white",bg="black",font=("times new roman",32,"bold"))
        lbltitle.pack(side=TOP,fill=X)

        bookframe=Frame(self.root,bd=15,relief=RIDGE)
        bookframe.place(x=270,y=150,width=1000,height=50)
        lblbook=Label(bookframe,text="BOOK AN APPOINTMENT",fg="white",bg="green",font=("times new roman",16,"bold"),padx=6,pady=6)
        lblbook.pack(fill=X)

        apptframe=Frame(self.root,bd=15,relief=RIDGE)
        apptframe.place(x=270,y=200,width=1000,height=400)
        lblappt=Label(apptframe,text="Patient's Name:",fg="white",bg="green",font=("times new roman",16,"bold"),padx=6,pady=6)
        lblappt.pack(fill=X)
        txtref=ttk.Entry(apptframe,font=("arial",12,"bold"),width=35)
        txtref.pack(fill=X)

        lbldis=Label(apptframe,text="Specialist",fg="white",bg="green",font=("times new roman",16,"bold"),padx=6,pady=6)
        lbldis.pack(fill=X)
        comdis=ttk.Combobox(apptframe,state="readonly",font=("arial",12,"bold"),width=35)
        comdis['value']=("--Select--","Heart-Dr.Ajit Singh Doval","Bone-Dr.Mahendra","Cancer-Dr.Bratt","Veternary-Dr.Avira Dessai","Dentist-Dr.Rutuja Dessai","Eye-Dr.Sukhvir Kaur","Lab analyst-Dr.Dishika Sharma")
        comdis.current(0)
        comdis.pack(fill=X)

        lbldescp=Label(apptframe,text="Description- Brief your issue/problem",fg="white",bg="green",font=("times new roman",16,"bold"),padx=6,pady=6)
        lbldescp.pack(fill=X)
        txtref=ttk.Entry(apptframe,font=("arial",12,"bold"),width=35)
        txtref.pack(fill=X)

        lblappttime=Label(apptframe,text="Appointment Time",fg="white",bg="green",font=("times new roman",16,"bold"),padx=6,pady=6)
        lblappttime.pack(fill=X)
        comappttime=ttk.Combobox(apptframe,state="readonly",font=("arial",12,"bold"),width=35)
        comappttime['value']=("--Select Hrs--","8AM","9AM","10AM","11AM","12PM","13PM","14PM","15PM","16PM","17PM","18PM","19PM","20PM","21PM")
        comappttime.current(0)
        comappttime.pack(fill=X)

        lbldate=Label(apptframe,text="Date",fg="white",bg="green",font=("times new roman",16,"bold"),padx=6,pady=6)
        lbldate.pack(fill=X)
        txtref=ttk.Entry(apptframe,font=("arial",12,"bold"),width=35)
        txtref.pack(fill=X)

        btnbook=Button(apptframe,command=self.appointment_data,text="Book",font=("times new roman",12,"bold"),bd=2,relief=RIDGE,fg="black",bg="red",activebackground="red",activeforeground="black")
        btnbook.place(x=430,y=333,width=100)

    def appointment_data(self):
        if appt.get()=="" or dis.get()=="--Select--" or desc.get()=="" or appttime.get()=="--Select Hrs--":
            messagebox.showerror("Error","All fields are mandatory")
        else:
            messagebox.showinfo("Successful","Appointment Booked Successfully!")




if __name__ == '__main__':
    root=Tk()
    app=appointment(root)
    root.mainloop() #to close the window, when user says.
