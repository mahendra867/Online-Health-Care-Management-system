from tkinter import*
from tkinter import ttk
from tkinter import messagebox
import mysql.connector




def main():
    win=Tk()
    app=login_panel(win)
    win.mainloop()


class login_panel:
    def __init__(self,root):
        self.root=root
        self.root.title("Login Page")
        self.root.geometry("1550x800+0+0")

        frame=Frame(self.root,bg="pink")
        frame.place(x=240,y=200,width=800,height=200)
        get_str=Label(frame,text="Login\nHere!\n",font=("times new roman",32,"bold"),bg="black",fg="white")
        get_str.place(x=30,y=45)

        #labels
        username=Label(frame,text="USERNAME",font=("times new roman",18,"italic"),bg="black",fg="white")
        username.place(x=150,y=45)
        self.txtuser=ttk.Entry(frame,font=("times new roman",18,"bold"))
        self.txtuser.place(x=300,y=45)

        password=Label(frame,text="PASSWORD",font=("times new roman",18,"italic"),bg="black",fg="white")
        password.place(x=150,y=100)
        self.txtpass=ttk.Entry(frame,font=("times new roman",18,"bold"))
        self.txtpass.place(x=300,y=100)

        #login button
        loginbtn=Button(frame,command=self.login,text="Login",font=("times new roman",18,"bold"),bd=3,fg="white",bg="red",activebackground="red",activeforeground="white")
        loginbtn.place(x=600,y=65,width=150,height=40)

        #registerbutton
        regbtn=Button(frame,text="Create a new account",command=self.register_window,font=("times new roman",12,"bold"),fg="black",bg="pink",activebackground="pink",activeforeground="black")
        regbtn.place(x=300,y=150,width=180,height=40)


    def register_window(self):
        self.new_window=Toplevel(self.root)
        self.app=register(self.new_window)




    def login(self):
        if self.txtuser.get()=="" or self.txtpass.get()=="":
            messagebox.showerror("Error","All fields are mandatory")
        elif self.txtuser.get()=="om" and self.txtpass.get()=="mahi":
            messagebox.showinfo("Successful","Logged In Successfully!")
        else:
            conn=mysql.connector.connect(host="localhost",user="root",password="Mahi@123",database="sys")
            my_cursor=conn.cursor()
            my_cursor.execute("select * from register where email=%s and pswd=%s",(
                                                                                        self.txtuser.get(),
                                                                                        self.txtpass.get()

                                                                                      ))

        row=my_cursor.fetchone()
        if row==None:
             messagebox.showerror("Error","Invalid Username & Password")
        else:
            open_main=messagebox.askyesno("YesNo","Access only admin")
            if open_main>0:
                self.new_window=Toplevel(self.root)
                self.app=mainpage(self.new_window)

            else:
                if not open_main :
                    return

        conn.commit()
        conn.close()




class register:
    #calling constructor
    def __init__(self,root):
        self.root=root
        self.root.title("Create New Account")
        self.root.geometry("1600x900+0+0")

        #variables
        self.var_fname=StringVar()
        self.var_lname=StringVar()
        self.var_contact=StringVar()
        self.var_email=StringVar()
        self.var_sq=StringVar()
        self.var_sa=StringVar()
        self.var_pswd=StringVar()
        self.var_cnfpswd=StringVar()
        self.var_checkbtn=IntVar()

        frame=Frame(self.root,bg="black")
        frame.place(x=250,y=100,width=800,height=800)

        reglbl=Label(frame,text="CREATE YOUR ACCOUNT!",font=("times new roman",28,"bold"),fg="yellow",bg="black")
        reglbl.place(x=140,y=20)

        #labels and entry fields
        fname=Label(frame,text="First Name",font=("times new roman",16,"bold"),fg="white",bg="black")
        fname.place(x=100,y=100)

        self.txt_fname=ttk.Entry(frame,textvariable=self.var_fname,font=("times new roman",15))
        self.txt_fname.place(x=100,y=130,width=250)

        lname=Label(frame,text="Last Name",font=("times new roman",16,"bold"),fg="white",bg="black")
        lname.place(x=370,y=100)

        self.txt_lname=ttk.Entry(frame,textvariable=self.var_lname,font=("times new roman",15))
        self.txt_lname.place(x=370,y=130,width=250)

        contact=Label(frame,text="Contact Number",font=("times new roman",16,"bold"),fg="white",bg="black")
        contact.place(x=100,y=170)

        self.txt_contact=ttk.Entry(frame,textvariable=self.var_contact,font=("times new roman",15))
        self.txt_contact.place(x=100,y=200,width=250)

        email=Label(frame,text="E-mail ID",font=("times new roman",16,"bold"),fg="white",bg="black")
        email.place(x=370,y=170)

        self.txt_email=ttk.Entry(frame,textvariable=self.var_email,font=("times new roman",15))
        self.txt_email.place(x=370,y=200,width=250)

        sq=Label(frame,text="Select security question", font=("times new roman",16,"bold"),fg="white",bg="black")
        sq.place(x=100,y=240)

        self.combo_sq=ttk.Combobox(frame,textvariable=self.var_sq,font=("times new roman",15,"bold"),state="readonly")
        self.combo_sq["values"]=("Select","Your birth place","your mom name","your GF name","Your favourite game")
        self.combo_sq.place(x=100,y=270,width=250)
        self.combo_sq.current(0)

        sa=Label(frame,text="Security Answer",font=("times new roman",15,"bold"),fg="white",bg="black")
        sa.place(x=370,y=240)

        self.txt_security=ttk.Entry(frame,textvariable=self.var_sa,font=("times new roman",15,"bold"))
        self.txt_security.place(x=370,y=270,width=250)

        pswd=Label(frame,text="Password",font=("times new roman",16,"bold"),fg="white",bg="black")
        pswd.place(x=100,y=310)

        self.txt_pswd=ttk.Entry(frame,textvariable=self.var_pswd,font=("times new roman",15,"bold"))
        self.txt_pswd.place(x=100,y=340,width=250)

        cnfpswd=Label(frame,text="Confirm Password",font=("times new roman",16,"bold"),fg="white",bg="black")
        cnfpswd.place(x=370,y=310)

        self.txt_cnfpswd=ttk.Entry(frame,textvariable=self.var_cnfpswd,font=("times new roman",15,"bold"))
        self.txt_cnfpswd.place(x=370,y=340,width=250)

        checkbtn=Checkbutton(frame,variable=self.var_checkbtn,text="I agree with all terms & conditions",font=("times new roman",8,"bold"),onvalue=1,offvalue=0)
        checkbtn.place(x=100,y=380)

        b1=Button(frame,command=self.register_data,text="Register",font=("times new roman",12,"bold"),bd=2,relief=RIDGE,fg="black",bg="red",activebackground="red",activeforeground="black")
        b1.place(x=100,y=420,width=100)


    def register_data(self):
        if self.var_fname.get()=="" or self.var_email.get()=="" or self.var_contact.get()=="" or self.var_sq.get()=="Select" or self.var_sa.get()=="Select":
            messagebox.showerror("Error","All fields are mandatory")
        elif self.var_pswd.get()!=self.var_cnfpswd.get():
            messagebox.showerror("Error","Password and Confirm Password must be same.")
        elif self.var_checkbtn.get()==0:
            messagebox.showerror("Error","Please check the box after you read terms and conditions")
        else:
           conn=mysql.connector.connect(host="localhost",user="root",password="Mahi@123",database="sys")
           my_cursor=conn.cursor()
           query=("select * from register where email=%s")
           value=(self.var_email.get(),)
           my_cursor.execute(query,value)
           row=my_cursor.fetchone()
           if row!=None:
               messagebox.showerror("Error","User Already Exist,Please Try Another Email")
           else:
                   my_cursor.execute("insert into register values(%s,%s,%s,%s,%s,%s,%s)",(self.var_fname.get(),
                                                                                          self.var_lname.get(),
                                                                                          self.var_contact.get(),
                                                                                          self.var_email.get(),
                                                                                          self.var_sq.get(),
                                                                                          self.var_sa.get(),
                                                                                          self.var_pswd.get()
                                                                                          ))
                   conn.commit()
                   conn.close()
                   messagebox.showinfo("success","Register Successfully")


class mainpage:
    def a(self):
        from Login_page import appointment
        self.new_window=Toplevel(self.root)
        self.app=appointment(self.new_window)

    def b(self):
        from Login_page import test
        self.new_window=Toplevel(self.root)
        self.app=test(self.new_window)

    def c(self):
        from Login_page import medication
        self.new_window=Toplevel(self.root)
        self.app=medication(self.new_window)

    def d(self):
        from Login_page import vaccine
        self.new_window=Toplevel(self.root)
        self.app=vaccine(self.new_window)

    def f(self):
        from Login_page import help
        self.new_window=Toplevel(self.root)
        self.app=help(self.new_window)

    def g(self):
        from Login_page import blood
        self.new_window=Toplevel(self.root)
        self.app=blood(self.new_window)


    def __init__(self,root):
        self.root=root
        self.root.title("Main Page")
        self.root.geometry("1450x800+0+0")

        lbltitle=Label(self.root,bd=20,relief=RIDGE,text="Online Health Management System",fg="white",bg="black",font=("times new roman",32,"bold"))
        lbltitle.pack(side=TOP,fill=X)

        buttonframe=Frame(self.root,bd=10,relief=RIDGE)
        buttonframe.place(x=0,y=172,width=1550,height=70)

        lblquick=Label(buttonframe,text="QUICK LINKS:",font=("times new roman",16,"bold"),padx=6,pady=6)
        lblquick.grid(row=0,column=0)

        btnapnt=Button(buttonframe,text="Book An Apointment",bg="red",fg="black",command = self.a,font=("times new roman",8,"bold"),padx=2,pady=2)
        btnapnt.place(x=160,y=0,width=200,height=50)

        test=Button(buttonframe,text="Tests",bg="red",fg="black",command=self.b,font=("times new roman",8,"bold"),padx=2,pady=2)
        test.place(x=400,y=0,width=100,height=50)

        mdct=Button(buttonframe,text="Medication",bg="red",fg="black",command=self.c,font=("times new roman",8,"bold"),padx=2,pady=2)
        mdct.place(x=540,y=0,width=150,height=50)

        vac=Button(buttonframe,text="Vaccines",bg="red",fg="black",command=self.d,font=("times new roman",8,"bold"),padx=2,pady=2)
        vac.place(x=720,y=0,width=150,height=50)

        rpt=Button(buttonframe,text="Help",bg="red",fg="black",command=self.f,font=("times new roman",8,"bold"),padx=2,pady=2)
        rpt.place(x=1060,y=0,width=150,height=50)

        bdd=Button(buttonframe,text="Blood Donate",bg="red",fg="black",command=self.g,font=("times new roman",8,"bold"),padx=2,pady=2)
        bdd.place(x=920,y=0,width=100,height=50)

        descframe=Frame(self.root,bd=10,relief=RIDGE)
        descframe.place(x=0,y=250,width=1280,height=150)

        lbldesc=Label(descframe,text="Welcome to Online Health Management System! \n Get well at one touch on your device resting at your home.This health management system makes it easy to find the doctors, which helps the patients to recover faster\n from the disease. Get your health reports and required tests. Finding the best respective doctor for a particular disease manually is a tough task.\n This health management system helps to find respective specialist doctors for a particular disease in the nearby location and also provides\n information and tips on how the disease can be cured. Get an appointment and either visit the clinic or request for home visit.",fg="white",bg="black",font=("times new roman",16,"bold"),padx=6,pady=6)
        lbldesc.pack(fill=X)

        boxframe=Frame(self.root,bd=10,relief=RIDGE)
        boxframe.place(x=0,y=400,width=1450,height=50)
        lblbox=Label(boxframe,text="Doctors Recommended",fg="white",bg="green",font=("times new roman",16,"bold"),padx=2,pady=2)
        lblbox.pack(fill=X)

        doctzeroframe=Frame(self.root,bd=10,relief=RIDGE)
        doctzeroframe.place(x=10,y=450,width=200,height=200)
        lbldoctzero=Label(doctzeroframe,text="HEART\nSPECIALIST\n\nDr.Ajit Singh Doval\n(MBBS)\n\nExperience:23 Y",fg="white",bg="grey",font=("times new roman",14,"bold"),padx=0,pady=0)
        lbldoctzero.pack(fill=X)

        doctoneframe=Frame(self.root,bd=10,relief=RIDGE)
        doctoneframe.place(x=260,y=450,width=200,height=375)
        lbldoctone=Label(doctoneframe,text="LAB\nANALYST\n\nDr.Dishika Sharma\n(MBBS)\n\nExperience:25 Y",fg="white",bg="grey",font=("times new roman",14,"bold"),padx=0,pady=0)
        lbldoctone.pack(fill=X)

        docttwoframe=Frame(self.root,bd=10,relief=RIDGE)
        docttwoframe.place(x=460,y=450,width=200,height=375)
        lbldocttwo=Label(docttwoframe,text="BONE\nSPECIALIST\n\nDr.Omkar\n(MBBS)\n\nExperience:23 Y",fg="white",bg="grey",font=("times new roman",14,"bold"),padx=0,pady=0)
        lbldocttwo.pack(fill=X)

        doctthreeframe=Frame(self.root,bd=10,relief=RIDGE)
        doctthreeframe.place(x=660,y=450,width=200,height=375)
        lbldoctthree=Label(doctthreeframe,text="VETERNARY\nSPECIALIST\n\nDr.Avira Dessai\n(MBBS)\n\nExperience:18 Y",fg="white",bg="grey",font=("times new roman",14,"bold"),padx=0,pady=0)
        lbldoctthree.pack(fill=X)

        doctfourframe=Frame(self.root,bd=10,relief=RIDGE)
        doctfourframe.place(x=860,y=450,width=200,height=375)
        lbldoctfour=Label(doctfourframe,text="DENTIST\n\n\nDr.Rutuja Dessai\n(MBBS)\n\nExperience:21 Y",fg="white",bg="grey",font=("times new roman",14,"bold"),padx=0,pady=0)
        lbldoctfour.pack(fill=X)

        doctfiveframe=Frame(self.root,bd=10,relief=RIDGE)
        doctfiveframe.place(x=1060,y=450,width=200,height=375)
        lbldoctfive=Label(doctfiveframe,text="EYE\nSPECIALIST\n\nDr.Sukhvir Kaur\n(MBBS)\n\nExperience:28 Y",fg="white",bg="grey",font=("times new roman",14,"bold"),padx=0,pady=0)
        lbldoctfive.pack(fill=X)

        doctsixframe=Frame(self.root,bd=10,relief=RIDGE)
        doctsixframe.place(x=1260,y=450,width=200,height=375)
        lbldoctsix=Label(doctsixframe,text="CANCER\nSPECIALIST\n\nDr.Bratt\n(MBBS)\n\nExperience:30 Y",fg="white",bg="grey",font=("times new roman",14,"bold"),padx=0,pady=0)
        lbldoctsix.pack(fill=X)




class appointment:

    def __init__(self,root):
        self.root=root
        self.root.title("Book an appointment")
        self.root.geometry("1600x900+0+0")



        lbltitle=Label(self.root,bd=20,relief=RIDGE,text="Online Health Management System",fg="white",bg="black",font=("times new roman",32,"bold"))
        lbltitle.pack(side=TOP,fill=X)

        bookframe=Frame(self.root,bd=15,relief=RIDGE)
        bookframe.place(x=270,y=150,width=1000,height=50)
        lblbook=Label(bookframe,text="BOOK AN APPOINTMENT",fg="white",bg="green",font=("times new roman",16,"bold"),padx=6,pady=6)
        lblbook.pack(fill=X)

        apptframe=Frame(self.root,bd=15,relief=RIDGE)
        apptframe.place(x=270,y=200,width=1000,height=400)
        lblappt=Label(apptframe,text="Patient's Name:",fg="white",bg="green",font=("times new roman",16,"bold"),padx=6,pady=6)
        lblappt.pack(fill=X)
        txtref=ttk.Entry(apptframe,font=("arial",12,"bold"),width=35)
        txtref.pack(fill=X)

        lbldis=Label(apptframe,text="Specialist",fg="white",bg="green",font=("times new roman",16,"bold"),padx=6,pady=6)
        lbldis.pack(fill=X)
        comdis=ttk.Combobox(apptframe,state="readonly",font=("arial",12,"bold"),width=35)
        comdis['value']=("--Select--","Heart","Bone","Cancer","Veternary","Dentist","Eye","Lab analyst")
        comdis.current(0)
        comdis.pack(fill=X)

        lbldescp=Label(apptframe,text="Description- Brief your issue/problem",fg="white",bg="green",font=("times new roman",16,"bold"),padx=6,pady=6)
        lbldescp.pack(fill=X)
        txtref=ttk.Entry(apptframe,font=("arial",12,"bold"),width=35)
        txtref.pack(fill=X)

        lbappttime=Label(apptframe,text="Appointment Time",fg="white",bg="green",font=("times new roman",16,"bold"),padx=6,pady=6)
        lbappttime.pack(fill=X)
        comappttime=ttk.Combobox(apptframe,state="readonly",font=("arial",12,"bold"),width=35)
        comappttime['value']=("--Select Hrs--","8AM","9AM","10AM","11AM","12PM","13PM","14PM","15PM","16PM","17PM","18PM","19PM","20PM","21PM")
        comappttime.current(0)
        comappttime.pack(fill=X)

        lbldate=Label(apptframe,text="Date",fg="white",bg="green",font=("times new roman",16,"bold"),padx=6,pady=6)
        lbldate.pack(fill=X)
        txtref=ttk.Entry(apptframe,font=("arial",12,"bold"),width=35)
        txtref.pack(fill=X)

        btnbook=Button(apptframe,text="Book",command=self.appointment_data,font=("times new roman",12,"bold"),bd=2,relief=RIDGE,fg="black",bg="red",activebackground="red",activeforeground="black")
        btnbook.place(x=430,y=333,width=100)

    def appointment_data(self):
        if self.lblappt.get()=="" or self.lbldis.get()=="--Select--" or self.lbldesc.get()=="" or self.lbappttime.get()=="--Select Hrs--":
            messagebox.showerror("Error","All fields are mandatory")
        else:
           conn=mysql.connector.connect(host="localhost",user="root",password="Mahi@123",database="sys")
           my_cursor=conn.cursor()
           my_cursor.execute("insert into appointment values(%s,%s,%s,%s,%s,%s)",(self.lblappt.get(),
                                                                                          sef.lbldis.get(),
                                                                                          self.lbldescp.get(),
                                                                                          self.lbappttime.get(),
                                                                                          self.comappttime.get(),
                                                                                          self.lbldate.get(),

                                                                                          ))



        conn.commit()
        conn.close()
        messagebox.showinfo("Successful","Appointment Booked Successfully!")



class test:

    #calling constructor


    def __init__(self,root):
        self.root=root
        self.root.title("Create New Account")
        self.root.geometry("1600x900+0+0")

        self.var_orderid=IntVar()
        self.var_fname=StringVar()
        self.var_contact=StringVar()
        self.var_drname=StringVar()
        self.var_pay=IntVar()
        self.var_testname=StringVar()
        self.var_checkbtn=IntVar()

        frame=Frame(self.root,bg="black")
        frame.place(x=0,y=0,width=1550,height=840)

        testlbl=Label(frame,text="TESTS",font=("times new roman",28,"bold"),fg="yellow",bg="black")
        testlbl.place(x=100,y=20)

        orderid=Label(frame,text="Test ID:",font=("times new roman",16,"bold"),fg="white",bg="black")
        orderid.place(x=700,y=20)
        self.txt_orderid=ttk.Entry(frame,textvariable=self.var_orderid,font=("times new roman",15))
        self.txt_orderid.place(x=700,y=50,width=250)

        fname=Label(frame,text="Full Name",font=("times new roman",16,"bold"),fg="white",bg="black")
        fname.place(x=100,y=110)
        self.txt_fname=ttk.Entry(frame,textvariable=self.var_fname,font=("times new roman",15))
        self.txt_fname.place(x=100,y=140,width=250)

        contact=Label(frame,text="Contact Number",font=("times new roman",16,"bold"),fg="white",bg="black")
        contact.place(x=500,y=110)
        self.txt_contact=ttk.Entry(frame,textvariable=self.var_contact,font=("times new roman",15))
        self.txt_contact.place(x=500,y=140,width=250)

        drname=Label(frame,text="Doctor Name",font=("times new roman",16,"bold"),fg="white",bg="black")
        drname.place(x=900,y=110)
        self.txt_drname=ttk.Entry(frame,textvariable=self.var_drname,font=("times new roman",15))
        self.txt_drname.place(x=900,y=140,width=250)

        pay=Label(frame,text="Amount Payable",font=("times new roman",16,"bold"),fg="white",bg="black")
        pay.place(x=100,y=240)
        self.txt_pay=ttk.Entry(frame,textvariable=self.var_pay,font=("times new roman",15))
        self.txt_pay.place(x=100,y=270,width=250)

        testname=Label(frame,text="Select particular\n required Test", font=("times new roman",16,"bold"),fg="white",bg="black")
        testname.place(x=1300,y=110)
        self.combo_testname=ttk.Combobox(frame,textvariable=self.var_testname,font=("times new roman",15,"bold"),state="readonly")
        self.combo_testname["values"]=("Select","Blood","Urine","Endoscopy","Biopsy","Genetic Testing")
        self.combo_testname.place(x=1300,y=140,width=250)
        self.combo_testname.current(0)

        checkbtn=Checkbutton(frame,variable=self.var_checkbtn,text="I agree with all terms & conditions",command=self.test,font=("times new roman",8,"bold"),onvalue=1,offvalue=0)
        checkbtn.place(x=100,y=320)

        b1=Button(frame,command=self.test_data,text="Done",font=("times new roman",12,"bold"),bd=2,relief=RIDGE,fg="black",bg="red",activebackground="red",activeforeground="black")
        b1.place(x=100,y=420,width=100)

        listlbl=Label(frame,text="RATE OF ALL TESTS\n 1.Blood: Rs.300\n 2.Urine: Rs100\n 3.Endoscopy: Rs1500\n 4.Biopsy: Rs5000\n 5.Genetic Testing: Rs6500",font=("times new roman",28,"bold"),fg="white",bg="grey")
        listlbl.place(x=900,y=250)

    def test_data(self):
        if self.var_orderid.get()=="" or self.var_fname.get()=="" or self.var_contact.get()=="" or self.var_testname.get()=="Select":
            messagebox.showerror("Error","All fields are mandatory")
        elif self.var_checkbtn.get()==0:
            messagebox.showerror("Error","Please check the box after you read terms and conditions")
        else:
            messagebox.showinfo("Successful","Sample will be collected soon!")


class medication:
    def e(self):
        from Login_page import medication
        self.new_window=Toplevel(self.root)
        self.app=medication(self.new_window)

    def __init__(self,root):
        self.root=root
        self.root.title("Medication")
        self.root.geometry("1600x900+0+0")

        lbltitle=Label(self.root,bd=20,relief=RIDGE,text="MEDICATION",fg="white",bg="black",font=("times new roman",32,"bold"))
        lbltitle.pack(side=TOP,fill=X)

        prsctframe=Frame(self.root,bd=15,relief=RIDGE)
        prsctframe.place(x=70,y=150,width=1400,height=50)
        lblprsct=Label(prsctframe,text="PRESCRIPTION",fg="white",bg="green",font=("times new roman",16,"bold"),padx=6,pady=6)
        lblprsct.pack(fill=X)

        medframe=Frame(self.root,bd=15,relief=RIDGE)
        medframe.place(x=70,y=200,width=700,height=400)

        lblpid=Label(medframe,text="Patient ID",font=("times new roman",12,"bold"),padx=2,pady=6)
        lblpid.grid(row=0,column=0)
        txtpid=ttk.Entry(medframe,font=("times new roman",12,"bold"),width=35)
        txtpid.grid(row=0,column=1)

        lblage=Label(medframe,text="Age of Patient",font=("times new roman",12,"bold"),padx=2,pady=6)
        lblage.grid(row=1,column=0)
        txtage=ttk.Entry(medframe,font=("times new roman",12,"bold"),width=35)
        txtage.grid(row=1,column=1)

        lblNameTablet=Label(medframe,text="Name of the tablet 1",font=("times new roman",12,"bold"),padx=2,pady=6)
        lblNameTablet.grid(row=2,column=0)
        comNameTablet=ttk.Combobox(medframe,font=("times new roman",12,"bold"),width=33)
        comNameTablet["values"]=("Halothane with vaporizer","Isoflurane","Ketamine Hydrochloride","Propofol","Diazepam","Acetyl Salicylic Acid Tab","Diclofenac Tab","Ibuprofen","Paracetamol Tab","Paracetamol Syrup","Paracetamol Injection","Azathioprine",
                                "Hydroxychloroquine phosphate","Adrenaline Bitartrate","Cetrizine","Activated Charcoal Antidote","Dimercaprol","Amoxicillin","Ampicillin","Azithromycin","Fluconazole","Metronidazole","Clindamycin","Dolo","--blood--","Dextran-40","Dextran-70",
                                "Fresh frozen plasma","Hydroxyethyl Starch (Hetastarch)","Polygeline","Albumin","Platelet Rich Plasma","--heart--","Acetyl salicylic acid","Diltiazem","Metoprolol","Digoxin","Dobutamine","--Contraceptives & Hormones--","Testosterone","Condoms",
                                "IUD containing Copper","Hormone Releasing IUD","Hormone Releasing IUD","Insulin Injection","Telmind25","--Vitamins & Minerals--","Ascorbic Acid",
                                "Calcium carbonate","Multivitamins","Nicotinamide","Vitamin A","Thiamine","Vitamin D (Ergocalciferol)","Calcium gluconate","--Cancer--","Asparaginase","Bleomycin","Carboplatin","Cytarabine","Docetaxel","Etoposide","Procarbazine","Vincristine",
                                "Mesna","Fludarabine","Rituximab","Arsenic trioxide","Dasatinib","Nilotinib")
        comNameTablet.grid(row=2,column=1)

        lblNameTablet1=Label(medframe,text="Name of the tablet 2",font=("times new roman",12,"bold"),padx=2,pady=6)
        lblNameTablet1.grid(row=3,column=0)
        comNameTablet1=ttk.Combobox(medframe,font=("times new roman",12,"bold"),width=33)
        comNameTablet1["values"]=("Halothane with vaporizer","Isoflurane","Ketamine Hydrochloride","Propofol","Diazepam","Acetyl Salicylic Acid Tab","Diclofenac Tab","Ibuprofen","Paracetamol Tab","Paracetamol Syrup","Paracetamol Injection","Azathioprine",
                                "Hydroxychloroquine phosphate","Adrenaline Bitartrate","Cetrizine","Activated Charcoal Antidote","Dimercaprol","Amoxicillin","Ampicillin","Azithromycin","Fluconazole","Metronidazole","Clindamycin","Dolo","--blood--","Dextran-40","Dextran-70",
                                "Fresh frozen plasma","Hydroxyethyl Starch (Hetastarch)","Polygeline","Albumin","Platelet Rich Plasma","--heart--","Acetyl salicylic acid","Diltiazem","Metoprolol","Digoxin","Dobutamine","--Contraceptives & Hormones--","Testosterone","Condoms",
                                "IUD containing Copper","Hormone Releasing IUD","Hormone Releasing IUD","Insulin Injection","Telmind25","--Vitamins & Minerals--","Ascorbic Acid",
                                "Calcium carbonate","Multivitamins","Nicotinamide","Vitamin A","Thiamine","Vitamin D (Ergocalciferol)","Calcium gluconate","--Cancer--","Asparaginase","Bleomycin","Carboplatin","Cytarabine","Docetaxel","Etoposide","Procarbazine","Vincristine",
                                "Mesna","Fludarabine","Rituximab","Arsenic trioxide","Dasatinib","Nilotinib")
        comNameTablet1.grid(row=3,column=1)

        lblNameTablet2=Label(medframe,text="Name of the tablet 3",font=("times new roman",12,"bold"),padx=2,pady=6)
        lblNameTablet2.grid(row=4,column=0)
        comNameTablet2=ttk.Combobox(medframe,font=("times new roman",12,"bold"),width=33)
        comNameTablet2["values"]=("Halothane with vaporizer","Isoflurane","Ketamine Hydrochloride","Propofol","Diazepam","Acetyl Salicylic Acid Tab","Diclofenac Tab","Ibuprofen","Paracetamol Tab","Paracetamol Syrup","Paracetamol Injection","Azathioprine",
                                "Hydroxychloroquine phosphate","Adrenaline Bitartrate","Cetrizine","Activated Charcoal Antidote","Dimercaprol","Amoxicillin","Ampicillin","Azithromycin","Fluconazole","Metronidazole","Clindamycin","Dolo","--blood--","Dextran-40","Dextran-70",
                                "Fresh frozen plasma","Hydroxyethyl Starch (Hetastarch)","Polygeline","Albumin","Platelet Rich Plasma","--heart--","Acetyl salicylic acid","Diltiazem","Metoprolol","Digoxin","Dobutamine","--Contraceptives & Hormones--","Testosterone","Condoms",
                                "IUD containing Copper","Hormone Releasing IUD","Hormone Releasing IUD","Insulin Injection","Telmind25","--Vitamins & Minerals--","Ascorbic Acid",
                                "Calcium carbonate","Multivitamins","Nicotinamide","Vitamin A","Thiamine","Vitamin D (Ergocalciferol)","Calcium gluconate","--Cancer--","Asparaginase","Bleomycin","Carboplatin","Cytarabine","Docetaxel","Etoposide","Procarbazine","Vincristine",
                                "Mesna","Fludarabine","Rituximab","Arsenic trioxide","Dasatinib","Nilotinib")
        comNameTablet2.grid(row=4,column=1)

        lblqty=Label(medframe,text="Quantity Tab1",font=("times new roman",12,"bold"),padx=2,pady=6)
        lblqty.grid(row=5,column=0)
        comqty=ttk.Combobox(medframe,font=("times new roman",12,"bold"),width=33)
        comqty["values"]=("--Select--","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15")
        comqty.grid(row=5,column=1)

        lblqty1=Label(medframe,text="Quantity Tab2",font=("times new roman",12,"bold"),padx=2,pady=6)
        lblqty1.grid(row=6,column=0)
        comqty1=ttk.Combobox(medframe,font=("times new roman",12,"bold"),width=33)
        comqty1["values"]=("--Select--","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15")
        comqty1.grid(row=6,column=1)

        lblqty2=Label(medframe,text="Quantity Tab3",font=("times new roman",12,"bold"),padx=2,pady=6)
        lblqty2.grid(row=7,column=0)
        comqty2=ttk.Combobox(medframe,font=("times new roman",12,"bold"),width=33)
        comqty2["values"]=("--Select--","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15")
        comqty2.grid(row=7,column=1)

        lblamt=Label(medframe,text="Amount in Rs.",font=("times new roman",12,"bold"),padx=2,pady=6)
        lblamt.grid(row=8,column=0)
        txtamt=ttk.Entry(medframe,font=("times new roman",12,"bold"),width=35)
        txtamt.grid(row=8,column=1)

        lbltype=Label(medframe,text="Payment Type",font=("times new roman",12,"bold"),padx=2,pady=6)
        lbltype.grid(row=9,column=0)
        comtype=ttk.Combobox(medframe,font=("times new roman",12,"bold"),width=33)
        comtype["values"]=("Cash","UPI","Digital payment")
        comtype.grid(row=9,column=1)

        btnpst=Button(medframe,command=self.showprsct,text="Prescribe",font=("times new roman",12,"bold"),width=20,height=2,bd=2,relief=RIDGE,fg="black",bg="green",activebackground="green",activeforeground="black")
        btnpst.place(x=460,y=150)

        btndashboard=Button(medframe,text="Back to Mainpage",command=root.destroy,font=("times new roman",12,"bold"),width=20,height=2,bd=2,relief=RIDGE,fg="black",bg="red",activebackground="red",activeforeground="black")
        btndashboard.place(x=460,y=210)

        #prescription output Frame
        pstoframe=Frame(self.root,bd=15,relief=RIDGE)
        pstoframe.place(x=770,y=200,width=700,height=400)

        self.txtpst=Text(pstoframe,font=("times new roman",12,"bold"),width=83,height=19,padx=2,pady=6)
        self.txtpst.grid(row=0,column=0)

    def showprsct(self):
        self.txtpst.insert(END,"Patient ID:\t\t\t"+self.pid.get() + "\n")
        self.txtpst=self.pid.get()
        self.txtpst.insert(END,"Age of Patient:\t\t\t"+self.pid.get() + "\n")
        self.txtpst.insert(END,"Name of the tablet 1:\t\t\t"+self.NameTable.get() + "\n")
        self.txtpst.insert(END,"Name of the tablet 2:\t\t\t"+self.NameTable1.get() + "\n")
        self.txtpst.insert(END,"Name of the tablet 3:\t\t\t"+self.NameTable2.get() + "\n")
        self.txtpst.insert(END,"Quantity Tab1:\t\t\t"+self.qty.get() + "\n")
        self.txtpst.insert(END,"Quantity Tab2:\t\t\t"+self.qty1.get() + "\n")
        self.txtpst.insert(END,"Quantity Tab3:\t\t\t"+self.qty2.get() + "\n")
        self.txtpst.insert(END,"Amount in Rs.:\t\t\t"+self.amt.get() + "\n")
        self.txtpst.insert(END,"Payment Type:\t\t\t"+self.type.get() + "\n")

        if self.pid.get() == '' or self.NameTable.get() == '' or self.NameTable1.get() == '' or self.NameTable2.get() == '' or self.qty.get() == '' or self.qty1.get() == '' or self.qty2.get() == '' or self.amt.get() == '' or self.type.get() == '':
            messagebox.showerror("Warning", "Please Fill Up All Boxes")
        else:
            # now we add to the database
            sql = "INSERT INTO 'medication' (Patient ID, Age of Patient, Name of the tablet 1, Name of the tablet 2, Name of the tablet 3, Quantity Tab1, Quantity Tab2, Quantity Tab3, Amount in Rs., Payment Type) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            c.execute(sql, (self.pid, self.age, self.NameTable, self.NameTable1, self.NameTable2, self.qty, self.qty1, self.qty2, self.amt, self.type))
            conn.commit()
            messagebox.showinfo("Success", "Prescribed!")



class vaccine:

         def __init__(self,root):

            self.root=root
            self.root.title("Vaccine panel")
            self.root.geometry("1600x900+0+0")

            self.var_vac=StringVar()
            self.var_dose=StringVar()
            self.var_age=IntVar()
            self.var_dov=StringVar()
            self.var_pnt=StringVar()
            self.var_checkbtn=StringVar()
            self.var_b1=StringVar()


            reglbl=Label(text="ONLINE HEALTH MANAGEMENT SYSTEM",font=("times new roman",28,"bold"),fg="maroon",bg="lightpink")
            reglbl.place(x=360,y=0)
            reglbl.pack(fill=X)

            frame=Frame(self.root,bg="orange")
            frame.place(x=0,y=50,width=1590,height=800)

            frame1=Frame(self.root,bg="lightblue")
            frame1.place(x=500,y=200,width=250,height=400)

            frame2=Frame(self.root,bg="purple")
            frame2.place(x=750,y=200,width=270,height=400)


            vac=Label(frame1,text="Select Vaccine:", font=("times new roman",16,"bold"),fg="white",bg="lightblue")
            vac.place(x=10,y=10)
            self.combo_vac=ttk.Combobox(frame2,textvariable=self.var_vac,font=("times new roman",15,"bold"),state="readonly")
            self.combo_vac["values"]=("Select","Covishield","Covaxin","Sputnik-V","Pfizer")
            self.combo_vac.place(x=10,y=10,width=250)
            self.combo_vac.current(0)

            dose=Label(frame1,text="Dose:", font=("times new roman",16,"bold"),fg="white",bg="lightblue")
            dose.place(x=10,y=60)
            self.combo_dose=ttk.Combobox(frame2,textvariable=self.var_dose,font=("times new roman",15,"bold"),state="readonly")
            self.combo_dose["values"]=("Select","First","second")
            self.combo_dose.place(x=10,y=60,width=250)
            self.combo_dose.current(0)

            age=Label(frame1,text="Age:", font=("times new roman",16,"bold"),fg="white",bg="lightblue")
            age.place(x=10,y=110)
            age=Label(frame1,text="*Age must be 18+", font=("times new roman",6,"bold"),fg="red",bg="lightblue")
            age.place(x=10,y=135)
            self.txt_age=ttk.Entry(frame2,textvariable=self.var_age,font=("times new roman",15))
            self.txt_age.place(x=10,y=110,width=250)

            dov=Label(frame1,text="Date of 1st vaccination:", font=("times new roman",16,"bold"),fg="white",bg="lightblue")
            dov.place(x=10,y=170)
            self.txt_dov=ttk.Entry(frame2,textvariable=self.var_dov,font=("times new roman",15))
            self.txt_dov.place(x=10,y=170,width=250)
            dov1=Label(frame1,text="*if taken",font=("times new roman",6,"bold"),fg="red",bg="lightblue")
            dov1.place(x=10,y=195)

            pnt=Label(frame1,text="Beneficiary Name:", font=("times new roman",16,"bold"),fg="white",bg="lightblue")
            pnt.place(x=10,y=230)
            self.txt_pnt=ttk.Entry(frame2,textvariable=self.var_pnt,font=("times new roman",15))
            self.txt_pnt.place(x=10,y=230,width=250)

            checkbtn=Checkbutton(frame2,variable=self.var_checkbtn,text="I am 18+",font=("times new roman",8,"bold"),onvalue=1,offvalue=0)
            checkbtn.place(x=10,y=280,width=250)

            b1=Button(frame2,command=self.vaccine_data,text="Book and Get Vaccinated",font=("times new roman",12,"bold"),bd=2,relief=RIDGE,fg="black",bg="red",activebackground="red",activeforeground="black")
            b1.place(x=28,y=334,width=220)

         def vaccine_data(self):

                if self.var_vac.get()=="" or self.var_dose.get()=="" or self.var_pnt.get()=="" or self.var_age.get()=="Select":
                     messagebox.showerror("Error","All fields are mandatory")
                elif self.var_checkbtn.get()==0:
                    messagebox.showerror("Error","Please check the box to validate 18+")
                else:
                     conn=mysql.connector.connect(host="localhost",user="root",password="Mahi@123",database="sys")
                     my_cursor=conn.cursor()
                     my_cursor.execute("insert into appointment values(%s,%s,%s,%s,%s)",(self.var_vac.get(),
                                                                                          self.var_dose.get(),
                                                                                          self.var_pnt.get(),
                                                                                          self.var_age.get(),
                                                                                          self.var_dov.get()


                                                                                          ))



                conn.commit()
                conn.close()
                messagebox.showinfo("Successful","Successfully Booked.\nYou will recieve Slot via message!")


class help:
        def __init__(self,root):
            self.root=root
            self.root.title("Help")
            self.root.geometry("1600x900+0+0")

            helplbl=Label(text="ONLINE HEALTH MANAGEMENT SYSTEM",font=("times new roman",28,"bold"),fg="maroon",bg="lightpink")
            helplbl.place(x=360,y=0)
            helplbl.pack(fill=X)

            frame=Frame(self.root,bg="lightblue")
            frame.place(x=0,y=50,width=1590,height=800)

            contact=Label(frame,text="Contact: 0880-6546-15", font=("times new roman",30,"bold"),fg="black",bg="lightblue")
            contact.place(x=600,y=200)

            email=Label(frame,text="Email-id: onlinehealthmanagementsystem@info", font=("times new roman",30,"bold"),fg="black",bg="lightblue")
            email.place(x=370,y=300)

            b1=Button(frame,text="Dashboard",command=root.destroy,font=("times new roman",12,"bold"),bd=2,relief=RIDGE,fg="black",bg="red",activebackground="red",activeforeground="black")
            b1.place(x=680,y=400,width=180)





class blood:
    def __init__(self,root):
        self.root=root
        self.root.title("Blood donate")
        self.root.geometry("1600x900+0+0")

        self.var_fname=StringVar()
        self.var_lname=StringVar()
        self.var_contact=IntVar()
        self.var_email=StringVar()
        self.var_bloodgrp=StringVar()
        self.var_checkbtn=IntVar()

        helplbl=Label(text="ONLINE HEALTH MANAGEMENT SYSTEM",font=("times new roman",28,"bold"),fg="maroon",bg="lightpink")
        helplbl.place(x=360,y=0)
        helplbl.pack(fill=X)

        frame=Frame(self.root,bg="lightblue")
        frame.place(x=0,y=50,width=1590,height=800)

        donate=Label(frame,text="Doante your Blood and Save a life", font=("times new roman",30,"bold"),fg="black",bg="lightblue")
        donate.place(x=460,y=125)

        frame1=Frame(self.root,bg="white")
        frame1.place(x=350,y=250,width=800,height=350)

        fname=Label(frame1,text="First Name:",font=("times new roman",16,"bold"),fg="black",bg="white")
        fname.place(x=20,y=20)
        self.txt_fname=ttk.Entry(frame1,textvariable=self.var_fname,font=("times new roman",15))
        self.txt_fname.place(x=150,y=20,width=250)

        lname=Label(frame1,text="Last Name:",font=("times new roman",16,"bold"),fg="black",bg="white")
        lname.place(x=400,y=20)
        self.txt_lname=ttk.Entry(frame1,textvariable=self.var_lname,font=("times new roman",15))
        self.txt_lname.place(x=530,y=20,width=250)

        contact=Label(frame1,text="Contact No:",font=("times new roman",16,"bold"),fg="black",bg="white")
        contact.place(x=20,y=80)
        self.txt_contact=ttk.Entry(frame1,textvariable=self.var_contact,font=("times new roman",15))
        self.txt_contact.place(x=150,y=80,width=250)

        email=Label(frame1,text="E-mail ID:",font=("times new roman",16,"bold"),fg="black",bg="white")
        email.place(x=400,y=80)
        self.txt_email=ttk.Entry(frame1,textvariable=self.var_email,font=("times new roman",15))
        self.txt_email.place(x=530,y=80,width=250)

        bloodgrp=Label(frame1,text="Blood Group:", font=("times new roman",16,"bold"),fg="black",bg="white")
        bloodgrp.place(x=20,y=140)
        self.combo_bloodgrp=ttk.Combobox(frame1,textvariable=self.var_bloodgrp,font=("times new roman",15,"bold"),state="readonly")
        self.combo_bloodgrp["values"]=("Select","A+","A-","B+","B-","O+","O-","AB+","AB-")
        self.combo_bloodgrp.place(x=150,y=140,width=600)
        self.combo_bloodgrp.current(0)

        checkbtn=Checkbutton(frame1,variable=self.var_checkbtn,text="I agree that I'm solely responsible for donating without anybody's force",font=("times new roman",8,"bold"),onvalue=1,offvalue=0)
        checkbtn.place(x=150,y=200)

        b1=Button(frame1,command=self.donate_data,text="Donate",font=("times new roman",16,"bold"),bd=2,relief=RIDGE,fg="black",bg="red",activebackground="red",activeforeground="black")
        b1.place(x=330,y=250,width=150)

    def donate_data(self):
        if self.var_fname.get()=="" or self.var_email.get()=="" or self.var_contact.get()=="" or self.var_bloodgrp.get()=="Select":
            messagebox.showerror("Error","All fields are mandatory")
        elif self.var_checkbtn.get()==0:
            messagebox.showerror("Error, Check the note","I agree that I'm solely responsible for donating without anybody's force")
        else:
            messagebox.showinfo("Successful","User Successfully Registered!")














if __name__ == '__main__':
    main()
