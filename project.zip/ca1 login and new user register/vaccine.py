from tkinter import*
from tkinter import ttk
from tkinter import messagebox

class vaccine:
    def __init__(self,root):
        self.root=root
        self.root.title("Vaccine panel")
        self.root.geometry("1600x900+0+0")

        self.var_vac=StringVar()
        self.var_dose=StringVar()
        self.var_age=IntVar()
        self.var_dov=StringVar()
        self.var_pnt=StringVar()
        self.var_checkbtn=StringVar()
        self.var_b1=StringVar()


        reglbl=Label(text="ONLINE HEALTH MANAGEMENT SYSTEM",font=("times new roman",28,"bold"),fg="maroon",bg="lightpink")
        reglbl.place(x=360,y=0)
        reglbl.pack(fill=X)

        frame=Frame(self.root,bg="orange")
        frame.place(x=0,y=50,width=1590,height=800)

        frame1=Frame(self.root,bg="lightblue")
        frame1.place(x=500,y=200,width=250,height=400)

        frame2=Frame(self.root,bg="purple")
        frame2.place(x=750,y=200,width=270,height=400)


        vac=Label(frame1,text="Select Vaccine:", font=("times new roman",16,"bold"),fg="white",bg="lightblue")
        vac.place(x=10,y=10)
        self.combo_vac=ttk.Combobox(frame2,textvariable=self.var_vac,font=("times new roman",15,"bold"),state="readonly")
        self.combo_vac["values"]=("Select","Covishield","Covaxin","Sputnik-V","Pfizer")
        self.combo_vac.place(x=10,y=10,width=250)
        self.combo_vac.current(0)

        dose=Label(frame1,text="Dose:", font=("times new roman",16,"bold"),fg="white",bg="lightblue")
        dose.place(x=10,y=60)
        self.combo_dose=ttk.Combobox(frame2,textvariable=self.var_dose,font=("times new roman",15,"bold"),state="readonly")
        self.combo_dose["values"]=("Select","First","second")
        self.combo_dose.place(x=10,y=60,width=250)
        self.combo_dose.current(0)

        age=Label(frame1,text="Age:", font=("times new roman",16,"bold"),fg="white",bg="lightblue")
        age.place(x=10,y=110)
        age=Label(frame1,text="*Age must be 18+", font=("times new roman",6,"bold"),fg="red",bg="lightblue")
        age.place(x=10,y=135)
        self.txt_age=ttk.Entry(frame2,textvariable=self.var_age,font=("times new roman",15))
        self.txt_age.place(x=10,y=110,width=250)

        dov=Label(frame1,text="Date of 1st vaccination:", font=("times new roman",16,"bold"),fg="white",bg="lightblue")
        dov.place(x=10,y=170)
        self.txt_dov=ttk.Entry(frame2,textvariable=self.var_dov,font=("times new roman",15))
        self.txt_dov.place(x=10,y=170,width=250)
        dov1=Label(frame1,text="*if taken",font=("times new roman",6,"bold"),fg="red",bg="lightblue")
        dov1.place(x=10,y=195)

        pnt=Label(frame1,text="Beneficiary Name:", font=("times new roman",16,"bold"),fg="white",bg="lightblue")
        pnt.place(x=10,y=230)
        self.txt_pnt=ttk.Entry(frame2,textvariable=self.var_pnt,font=("times new roman",15))
        self.txt_pnt.place(x=10,y=230,width=250)

        checkbtn=Checkbutton(frame2,variable=self.var_checkbtn,text="I am 18+",font=("times new roman",8,"bold"),onvalue=1,offvalue=0)
        checkbtn.place(x=10,y=280,width=250)

        b1=Button(frame2,command=self.vaccine_data,text="Book and Get Vaccinated",font=("times new roman",12,"bold"),bd=2,relief=RIDGE,fg="black",bg="red",activebackground="red",activeforeground="black")
        b1.place(x=28,y=334,width=220)

    def vaccine_data(self):
        if self.var_vac.get()=="" or self.var_dose.get()=="" or self.var_pnt.get()=="" or self.var_age.get()=="Select":
            messagebox.showerror("Error","All fields are mandatory")
        elif self.var_checkbtn.get()==0:
            messagebox.showerror("Error","Please check the box to validate 18+")
        else:
            messagebox.showinfo("Successful","Successfully Booked.\nYou will recieve Slot via message!")


if __name__ == '__main__':
    root=Tk()
    app=vaccine(root)
    root.mainloop()
