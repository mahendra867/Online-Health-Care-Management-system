from tkinter import*
from tkinter import ttk
from tkinter import messagebox

class help:
    def __init__(self,root):
        self.root=root
        self.root.title("Help")
        self.root.geometry("1600x900+0+0")

        helplbl=Label(text="ONLINE HEALTH MANAGEMENT SYSTEM",font=("times new roman",28,"bold"),fg="maroon",bg="lightpink")
        helplbl.place(x=360,y=0)
        helplbl.pack(fill=X)

        frame=Frame(self.root,bg="lightblue")
        frame.place(x=0,y=50,width=1590,height=800)

        contact=Label(frame,text="Contact: 0880-6546-15", font=("times new roman",30,"bold"),fg="black",bg="lightblue")
        contact.place(x=600,y=200)

        email=Label(frame,text="Email-id: onlinehealthmanagementsystem@info", font=("times new roman",30,"bold"),fg="black",bg="lightblue")
        email.place(x=370,y=300)

        b1=Button(frame,text="Dashboard",font=("times new roman",12,"bold"),bd=2,relief=RIDGE,fg="black",bg="red",activebackground="red",activeforeground="black")
        b1.place(x=680,y=400,width=180)




if __name__ == '__main__':
    root=Tk()
    app=help(root)
    root.mainloop()
