from tkinter import*
from tkinter import ttk
from tkinter import messagebox

class blood:
    def __init__(self,root):
        self.root=root
        self.root.title("Blood donate")
        self.root.geometry("1600x900+0+0")

        self.var_fname=StringVar()
        self.var_lname=StringVar()
        self.var_contact=IntVar()
        self.var_email=StringVar()
        self.var_bloodgrp=StringVar()
        self.var_checkbtn=IntVar()

        helplbl=Label(text="ONLINE HEALTH MANAGEMENT SYSTEM",font=("times new roman",28,"bold"),fg="maroon",bg="lightpink")
        helplbl.place(x=360,y=0)
        helplbl.pack(fill=X)

        frame=Frame(self.root,bg="lightblue")
        frame.place(x=0,y=50,width=1590,height=800)

        donate=Label(frame,text="Doante your Blood and Save a life", font=("times new roman",30,"bold"),fg="black",bg="lightblue")
        donate.place(x=460,y=125)

        frame1=Frame(self.root,bg="white")
        frame1.place(x=350,y=250,width=800,height=350)

        fname=Label(frame1,text="First Name:",font=("times new roman",16,"bold"),fg="black",bg="white")
        fname.place(x=20,y=20)
        self.txt_fname=ttk.Entry(frame1,textvariable=self.var_fname,font=("times new roman",15))
        self.txt_fname.place(x=150,y=20,width=250)

        lname=Label(frame1,text="Last Name:",font=("times new roman",16,"bold"),fg="black",bg="white")
        lname.place(x=400,y=20)
        self.txt_lname=ttk.Entry(frame1,textvariable=self.var_lname,font=("times new roman",15))
        self.txt_lname.place(x=530,y=20,width=250)

        contact=Label(frame1,text="Contact No:",font=("times new roman",16,"bold"),fg="black",bg="white")
        contact.place(x=20,y=80)
        self.txt_contact=ttk.Entry(frame1,textvariable=self.var_contact,font=("times new roman",15))
        self.txt_contact.place(x=150,y=80,width=250)

        email=Label(frame1,text="E-mail ID:",font=("times new roman",16,"bold"),fg="black",bg="white")
        email.place(x=400,y=80)
        self.txt_email=ttk.Entry(frame1,textvariable=self.var_email,font=("times new roman",15))
        self.txt_email.place(x=530,y=80,width=250)

        bloodgrp=Label(frame1,text="Blood Group:", font=("times new roman",16,"bold"),fg="black",bg="white")
        bloodgrp.place(x=20,y=140)
        self.combo_bloodgrp=ttk.Combobox(frame1,textvariable=self.var_bloodgrp,font=("times new roman",15,"bold"),state="readonly")
        self.combo_bloodgrp["values"]=("Select","A+","A-","B+","B-","O+","O-","AB+","AB-")
        self.combo_bloodgrp.place(x=150,y=140,width=600)
        self.combo_bloodgrp.current(0)

        checkbtn=Checkbutton(frame1,variable=self.var_checkbtn,text="I agree that I'm solely responsible for donating without anybody's force",font=("times new roman",8,"bold"),onvalue=1,offvalue=0)
        checkbtn.place(x=150,y=200)

        b1=Button(frame1,command=self.donate_data,text="Donate",font=("times new roman",16,"bold"),bd=2,relief=RIDGE,fg="black",bg="red",activebackground="red",activeforeground="black")
        b1.place(x=330,y=250,width=150)

    def donate_data(self):
        if self.var_fname.get()=="" or self.var_email.get()=="" or self.var_contact.get()=="" or self.var_bloodgrp.get()=="Select":
            messagebox.showerror("Error","All fields are mandatory")
        elif self.var_checkbtn.get()==0:
            messagebox.showerror("Error, Check the note","I agree that I'm solely responsible for donating without anybody's force")
        else:
            messagebox.showinfo("Successful","User Successfully Registered!")

if __name__ == '__main__':
    root=Tk()
    app=blood(root)
    root.mainloop()
