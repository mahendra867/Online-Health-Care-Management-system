from tkinter import*
from tkinter import ttk
from tkinter import messagebox
import mysql.connector

class register:
    #calling constructor
    def __init__(self,root):
        self.root=root
        self.root.title("Create New Account")
        self.root.geometry("1600x900+0+0")

        #variables
        self.var_fname=StringVar()
        self.var_lname=StringVar()
        self.var_contact=StringVar()
        self.var_email=StringVar()
        self.var_sq=StringVar()
        self.var_sa=StringVar()
        self.var_pswd=StringVar()
        self.var_cnfpswd=StringVar()
        self.var_checkbtn=IntVar()

        frame=Frame(self.root,bg="black")
        frame.place(x=250,y=100,width=800,height=800)

        reglbl=Label(frame,text="CREATE YOUR ACCOUNT!",font=("times new roman",28,"bold"),fg="yellow",bg="black")
        reglbl.place(x=140,y=20)

        #labels and entry fields
        fname=Label(frame,text="First Name",font=("times new roman",16,"bold"),fg="white",bg="black")
        fname.place(x=100,y=100)

        self.txt_fname=ttk.Entry(frame,textvariable=self.var_fname,font=("times new roman",15))
        self.txt_fname.place(x=100,y=130,width=250)

        lname=Label(frame,text="Last Name",font=("times new roman",16,"bold"),fg="white",bg="black")
        lname.place(x=370,y=100)

        self.txt_lname=ttk.Entry(frame,textvariable=self.var_lname,font=("times new roman",15))
        self.txt_lname.place(x=370,y=130,width=250)

        contact=Label(frame,text="Contact Number",font=("times new roman",16,"bold"),fg="white",bg="black")
        contact.place(x=100,y=170)

        self.txt_contact=ttk.Entry(frame,textvariable=self.var_contact,font=("times new roman",15))
        self.txt_contact.place(x=100,y=200,width=250)

        email=Label(frame,text="E-mail ID",font=("times new roman",16,"bold"),fg="white",bg="black")
        email.place(x=370,y=170)

        self.txt_email=ttk.Entry(frame,textvariable=self.var_email,font=("times new roman",15))
        self.txt_email.place(x=370,y=200,width=250)

        sq=Label(frame,text="Select security question", font=("times new roman",16,"bold"),fg="white",bg="black")
        sq.place(x=100,y=240)

        self.combo_sq=ttk.Combobox(frame,textvariable=self.var_sq,font=("times new roman",15,"bold"),state="readonly")
        self.combo_sq["values"]=("Select","Your birth place","your mom name","your GF name","Your favourite game")
        self.combo_sq.place(x=100,y=270,width=250)
        self.combo_sq.current(0)

        sa=Label(frame,text="Security Answer",font=("times new roman",15,"bold"),fg="white",bg="black")
        sa.place(x=370,y=240)

        self.txt_security=ttk.Entry(frame,textvariable=self.var_sa,font=("times new roman",15,"bold"))
        self.txt_security.place(x=370,y=270,width=250)

        pswd=Label(frame,text="Password",font=("times new roman",16,"bold"),fg="white",bg="black")
        pswd.place(x=100,y=310)

        self.txt_pswd=ttk.Entry(frame,textvariable=self.var_pswd,font=("times new roman",15,"bold"))
        self.txt_pswd.place(x=100,y=340,width=250)

        cnfpswd=Label(frame,text="Confirm Password",font=("times new roman",16,"bold"),fg="white",bg="black")
        cnfpswd.place(x=370,y=310)

        self.txt_cnfpswd=ttk.Entry(frame,textvariable=self.var_cnfpswd,font=("times new roman",15,"bold"))
        self.txt_cnfpswd.place(x=370,y=340,width=250)

        checkbtn=Checkbutton(frame,variable=self.var_checkbtn,text="I agree with all terms & conditions",font=("times new roman",8,"bold"),onvalue=1,offvalue=0)
        checkbtn.place(x=100,y=380)

        b1=Button(frame,command=self.register_data,text="Register",font=("times new roman",12,"bold"),bd=2,relief=RIDGE,fg="black",bg="red",activebackground="red",activeforeground="black")
        b1.place(x=100,y=420,width=100)

        b2=Button(frame,text="Login Page",font=("times new roman",12,"bold"),bd=2,relief=RIDGE,fg="black",bg="red",activebackground="red",activeforeground="black")
        b2.place(x=520,y=420,width=100)

    def register_data(self):
        if self.var_fname.get()=="" or self.var_email.get()=="" or self.var_contact.get()=="" or self.var_sq.get()=="Select" or self.var_sa.get()=="Select":
            messagebox.showerror("Error","All fields are mandatory")
        elif self.var_pswd.get()!=self.var_cnfpswd.get():
            messagebox.showerror("Error","Password and Confirm Password must be same.")
        elif self.var_checkbtn.get()==0:
            messagebox.showerror("Error","Please check the box after you read terms and conditions")
        else:
           conn=mysql.connector.connect(host="localhost",user="root",password="Mahi@123",database="sys")
           my_cursor=conn.cursor()
           query=("select * from register where email=%s")
           value=(self.var_email.get(),)
           my_cursor.execute(query,value)
           row=my_cursor.fetchone()
           if row!=None:
               messagebox.showerror("Error","User Already Exist,Please Try Another Email")
           else:
                   my_cursor.execute("insert into register values(%s,%s,%s,%s,%s,%s,%s)",(self.var_fname.get(),
                                                                                          self.var_lname.get(),
                                                                                          self.var_contact.get(),
                                                                                          self.var_email.get(),
                                                                                          self.var_sq.get(),
                                                                                          self.var_sa.get(),
                                                                                          self.var_pswd.get()
                                                                                          ))
                   conn.commit()
                   conn.close()
                   messagebox.showinfo("success","Register Successfully")
                   
           
           









#object opening and object calling of class (object):
if __name__ == '__main__':
    root=Tk()
    app=register(root)
    root.mainloop() #to close the window, when user says.
